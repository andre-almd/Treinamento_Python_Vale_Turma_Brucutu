# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 18:28:05 2020

@author: André
"""

import matplotlib.pyplot as plt
import cv2
import numpy as np

# Espaço de cores
# *****************************************************************************
# RGB
img = cv2.imread('arquivos/00-cachorro.jpg')
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
plt.imshow(img)

# HSL


# HSV


# Mudar o Hue (matiz) do espaço HSV
# No openCV H[0 - 179], S[0-255] e V[0-255]





# Threshold
# *****************************************************************************
'''
# Interessante em aplicações onde os formatos e bordas são mais interessantes.
# Segmenta a imagem em diferentes partes (Preto e branco)
# 
'''

# Ler imagem em escala de cinza
img = cv2.imread('arquivos/rainbow.jpg', 0)
plt.imshow(img, cmap='gray')

# Threshold binário ou binário-inverso


# Threshold trunc


#Treshold adaptativo



# Histogramas por canais BGR
# ********************************************************************************
horse = cv2.imread('arquivos/horse.jpg')
horseRGB = cv2.cvtColor(horse, cv2.COLOR_BGR2RGB)
plt.imshow(horseRGB)

brick = cv2.imread('arquivos/bricks.jpg')
brickRGB = cv2.cvtColor(brick, cv2.COLOR_BGR2RGB)
plt.imshow(brickRGB)



# Plotar o hist dos três canais


# Blurring and smoothing (Desfocagem e suavização)
# *****************************************************************************
'''
 # Útil em situações para tirar ruídos ou em aplicações para focar em detalhes gerais
# Muito usado combinado com detecção de bordas
# Sem desfocagem e suavização os algoritmos reconhecem muitas bordas desnecessárias. 
'''
# Ler imagem em escala de cinza - trabalhar com floar32, range de 0-1


# Correção de Gamma: Aumenta ou diminiu o brilho da imagem


# filtro com convolução


# Suavização com blur e gauss


#Blur pela média dos pixels sob o filtro


# Suavização pelo filtro gaussiano
