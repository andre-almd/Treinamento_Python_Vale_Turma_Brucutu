# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 16:03:31 2020

@author: André
"""

import numpy as np
import matplotlib.pyplot as plt

from PIL import Image

# ler o arquivo da imagem e plotar


# Converte para array


# Zerar as contribuições dos canais GB


# R G B

#Valores dos canais individuais


#Valores do canal Verde 0-255 

#Valores do canal Azul 0-255 


# Zerar os canais Verde e Azul


# Fatiar a imagem em partes específicas. 


# Mistura: 0:transparente - 1:opaco

