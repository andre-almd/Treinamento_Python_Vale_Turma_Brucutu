# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 17:44:18 2020

@author: André
"""

import matplotlib.pyplot as plt

import cv2

# Códigos com OpenCV

# Caminho errado
img = cv2.imread('arquivos/00-cachoro.jpg')
type(img)

# Caminho certo
img = cv2.imread('arquivos/00-cachorro.jpg')
type(img)
img.shape

# plotar imagem

#cv2 - Channels BGR


# Transformar canais


# Ler diretamente em escala de cinza


# Mudar tamanho (Observar que a dimensão é ao contrário do que indica o shape) W,H


# Mudar tamanho por escala de W,H


# Flip


# Salvar imagem


'''
fig = plt.figure(figsize=(30,30))
ax = fig.add_subplot(111)
ax.imshow(img)
'''

# Modificar imagem com loop for (Observar plot com cv2)
# ********************************************************************************

# Mudar cores dos pixels
