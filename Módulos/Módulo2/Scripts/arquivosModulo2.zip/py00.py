# -*- coding: utf-8 -*-
"""
Created on Sun Apr 26 14:24:28 2020

@author: André
"""

# Criando arrays

import numpy as np

# 1 dimensão


# 2 dimensões


# 3 dimensões


# Gerar arrays com funções específicas



# Mudar forma